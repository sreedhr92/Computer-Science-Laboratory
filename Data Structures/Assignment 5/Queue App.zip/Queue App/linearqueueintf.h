struct queue 
{
	int front,rear,capacity;
	int *a;
};

