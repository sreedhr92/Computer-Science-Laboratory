struct queue 
{
	int front,rear,capacity,size;
	int *a;
};

